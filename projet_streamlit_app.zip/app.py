import streamlit as st
import pandas as pd
import joblib

# Charger le modèle
model = joblib.load("modele_projet.pkl")

features = [
    "Style", "Price", "Rating", "Size", "Season", "NeckLine", "SleeveLength",
    "waiseline", "Material", "FabricType", "Decoration", "Pattern Type", "TotalSales"
]

st.title("Prédiction de Recommandation de Robe 👗")
st.markdown("**Entrez les caractéristiques d'une robe pour prédire si elle sera recommandée.**")

input_data = {}
for feature in features:
    if feature == "Rating":
        input_data[feature] = st.slider("Note moyenne (Rating)", 0.0, 5.0, 3.5)
    elif feature == "TotalSales":
        input_data[feature] = st.number_input("Total des ventes", min_value=0, value=1000)
    else:
        input_data[feature] = st.text_input(f"{feature}")

if st.button("Prédire"):
    input_df = pd.DataFrame([input_data])
    prediction = model.predict(input_df)[0]
    if prediction == 1:
        st.success("✅ Cette robe est RECOMMANDÉE !")
    else:
        st.error("❌ Cette robe n'est PAS recommandée.")
