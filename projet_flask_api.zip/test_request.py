import requests

url = "http://127.0.0.1:5000/predict"

payload = {
    "Style": 1,
    "Price": 0,
    "Rating": 4.2,
    "Size": 1,
    "Season": 3,
    "NeckLine": 2,
    "SleeveLength": 4,
    "waiseline": 2,
    "Material": 3,
    "FabricType": 1,
    "Decoration": 0,
    "Pattern Type": 4,
    "TotalSales": 2500
}

response = requests.post(url, json=payload)

if response.status_code == 200:
    print("✅ Réponse de l'API :")
    print(response.json())
else:
    print("❌ Erreur :")
    print(response.status_code, response.text)
